<?php
	session_start();
	require_once("gestionBD.php");
	require_once("gestionarViajes.php");
		
	if (isset($_SESSION["formulario_admin"])) {
		$nuevoViaje= $_SESSION["formulario_admin"];
		$_SESSION["formulario_admin"] = null;
		$_SESSION["erroresA"] = null;
	}
	else{
		Header("Location: form_admin.php");
	}
	
	$conexion = crearConexionBD(); 

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>CityBus | Ruta registrada </title>
    <link rel="stylesheet" type="text/css" href="css/CSS.css" />
</head>

<body>
	<?php
		include_once("cabecera.php");
	?>
	
	
		<?php if (alta_Viaje($conexion, $nuevoViaje)) { ?>
				<h1>Ruta registrada con éxito</h1>
				<div >	
			   		<p>Pulsa <a href="inicio.php">aquí</a> para acceder al inicio y conectarte con tu cuenta.</p> 
				</div>
		<?php } else { ?>
				<h1>¡NO SE HA PODIDO GUARDAR EN LA BASE DE DATOS!</h1>
				<div >	
					Pulsa <a href="form_admin.php">aquí</a> para volver al formulario o pulsa <a href="Login.php">aquí</a> para conectarte con tu cuenta.
				</div>
		<?php } ?>

	<?php
		include_once("pie.php");
	?>
</body>
</html>
<?php
	cerrarConexionBD($conexion);
?>