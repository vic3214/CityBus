<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8" />
		<link rel="stylesheet" href="css/CSS.css" />
		<title>Evianos tus sugerencias</title>
	</head>	
	
	<body>
		<a href="contacto.php" align="center">Pulsa el enlace para ver el correo de la empresa y enviar tu sugerencia</a>
	</body>
</html>