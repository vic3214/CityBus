<?php
	session_start();
	
	require_once("gestionBD.php");
	
	if (!isset($_SESSION["formulario_admin"])) {
		$formulario_admin['ruta'] = "";
		$formulario_admin['fechaviaje'] = "";
		$formulario_admin['autobus'] = "";
		$formulario_admin['horallegada'] = "";
		$formulario_admin['horasalida'] = "";
		$formulario_admin['precio'] = "";
	
		$_SESSION["formulario_admin"] = $formulario_admin;
	}else{
		$formulario_admin = $_SESSION["formulario_admin"];
	}
	
	
	if (isset($_SESSION["erroresA"])){
		$erroresA = $_SESSION["erroresA"];
		unset($_SESSION["erroresA"]);
	}
	$conexion=crearConexionBD();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="css/CSS.css" />
   <link rel="stylesheet" type="text/css" href="css/efecto_form.css" />
   <script src="JavaScript/validacion_ruta.js" type="text/javascript"></script>
  <title>CityBus | Añadir ruta</title>
</head>

<body>
	
	<?php
		include_once("cabecera.php");
	?>
	
	<?php 
		// Mostrar los erroes de validación (Si los hay)
		if (isset($erroresA) && count($erroresA)>0) { 
	    	echo "<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
    		foreach($erroresA as $error){
    			echo $error;
			} 
    		echo "</div>";
  		}
	?>
	
	<form id="altaRuta" method="get" action="validacion_alta_viaje.php" onsubmit="return ValidacionesRuta();" >  
		<p><i>Todos los campos a rellenar son obligatorios</i></p>
		<fieldset><legend>Registro de la ruta</legend>
			<br />
			<fieldset><legend>Ruta</legend>
			<div><label for="ruta">Ruta:</label>
			<input id="ruta" name="ruta" type="text" placeholder="2" pattern="[0-9]{1,}" title="Número correspondiente a la ruta" oninput="validaRuta();" value="<?php echo $formulario_admin['ruta'];?>" required>
			</div>
			<br />
			
			<div><label for="precio">Precio del billete:</label>
				<input id="precio" name="precio" type="text" placeholder="Ej: 9"  pattern="[0-9]{1,}[,][0-9]{2}" oninput="validaPrecio();" value="<?php echo $formulario_admin['precio'];?>" required>
			</div></fieldset>
			<br />
		
			
			<fieldset><legend>Información sobre el autobús</legend>
			<div><label for="autobus">Autobús:</label>
			<input id="autobus" name="autobus" type="text" placeholder="Matrícula del vehículo" pattern="[0-9]{4}[A-Z]{3}" oninput="validaMatricula();" value="<?php echo $formulario_admin['autobus'];?>" required/>
			</div>
			<br />
			</fieldset>
			<br />
			
			<fieldset><legend>Información sobre la hora</legend>
			<br />
			<div><label for="horasalida">Hora de salida:</label>
			<input id="horasalida" name="horasalida" type="text" placeholder="Formato: hh:mm" pattern="[0-9]{2}[:][0-9]{2}" oninput="validaHoraSalida();" value="<?php echo $formulario_admin['horasalida'];?>" required/>
			</div>
			<br/>
			
			<div><label for="horallegada">Hora de llegada:</label>
			<input id="horallegada" name="horallegada" type="text" placeholder="Formato: hh:mm" pattern="[0-9]{2}[:][0-9]{2}" oninput="validaHoraLlegada();"  value="<?php echo $formulario_admin['horallegada'];?>" required/>
			</div>
			<br />
			<div><label for="fechaviaje">Fecha:</label>
			<input id="fechaviaje" name="fechaviaje" type="date" value="<?php echo $formulario_admin['fechaviaje'];?>" required/>
			</div>
			<br />
		</fieldset>
		</fieldset>

		<div><input class="boton2" type="submit" value="Registrar viaje" /></div>
	</form>
	
	<?php
		include_once("pie.php");
		cerrarConexionBD($conexion);
	?>
	</body>
</html>