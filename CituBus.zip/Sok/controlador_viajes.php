<?php	
	session_start();
	// añadido nuevos $viaje
	if (isset($_REQUEST["IDVIAJE"])) {
		$viaje["IDVIAJE"] = $_REQUEST["IDVIAJE"];
		$viaje["IDRUTA"] = $_REQUEST["IDRUTA"];
		$viaje["MATRICULA"] = $_REQUEST["MATRICULA"];
		$viaje["NOMBRERUTA"] = $_REQUEST["NOMBRERUTA"];
		$viaje["FECHAVIAJE"] = $_REQUEST["FECHAVIAJE"];
		$viaje["HORASALIDA"] = $_REQUEST["HORASALIDA"];
		$viaje["HORALLEGADA"] = $_REQUEST["HORALLEGADA"];
		$viaje["PRECIO"] = $_REQUEST["PRECIO"];
		$viaje["AUTOBUS"] = $_REQUEST["AUTOBUS"];
		
		
		$_SESSION["viaje"] = $viaje;
	}
		Header("Location: compra_billete.php");

?>