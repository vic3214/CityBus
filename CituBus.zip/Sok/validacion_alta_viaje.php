<?php
	session_start();

	require_once("gestionBD.php");


	if (isset($_SESSION["formulario_admin"])) {
	
		$nuevoViaje["ruta"] = $_REQUEST["ruta"];
		$nuevoViaje["fechaviaje"] = $_REQUEST["fechaviaje"];
		$nuevoViaje["autobus"] = $_REQUEST["autobus"];
		$nuevoViaje["horasalida"] = $_REQUEST["horasalida"];
		$nuevoViaje["horallegada"] = $_REQUEST["horallegada"];
		$nuevoViaje["precio"] = $_REQUEST["precio"];
		
		// Guardar la variable local con los datos del formulario en la sesión.
		$_SESSION["formulario_admin"] = $nuevoViaje;		
	}
	else // En caso contrario, vamos al formulario
		Header("Location: form_admin.php");

	// Validamos el formulario en servidor
	$conexion = crearConexionBD(); 
	$erroresA = validarDatosViaje($conexion, $nuevoViaje);
	cerrarConexionBD($conexion);
	
	// Si se han detectado errores
	if (count($erroresA)>0) {
		// Guardo en la sesión los mensajes de error y volvemos al formulario
		$_SESSION["erroresA"] = $erroresA;
		Header('Location: form_admin.php');
	} else
		// Si todo va bien, vamos a la página de acción (inserción del usuario en la base de datos)
		Header('Location: accion_validacion_ruta.php');

// Validación en servidor del formulario de alta de usuario

function validarDatosViaje($conexion, $nuevoViaje){
	$horasalida= strtotime($nuevoViaje['horasalida']);
	$horallegada= strtotime($nuevoViaje['horallegada']);
	
	$errores=array();
	// Validación de la ruta
	if($nuevoViaje["ruta"]==""){
		$erroresA[] = "<p>La ruta no puede estar vacía</p>";
	}else if(!preg_match("/[0-9]{1,}/", $nuevoViaje["ruta"])){
		$erroresA[] = "<p>La ruta debe ser un número entero del 1 en adelante </p>";
	}
	// Validación del Precio			
	if($nuevoViaje["precio"]==""){
		$erroresA[] = "<p>El nombre no puede estar vacío</p>";
	}else if(!preg_match("/[0-9]{1,}[,][0-9]{2}/", $nuevoViaje["precio"])){ 
		$erroresA[]="<p>El precio debe tener parte entera y decimal separada por un punto </p>";
	}

	// Validación del hora de llegada y hora de salida
	if($nuevoViaje["horallegada"]="" || $nuevoViaje["horasalida"]="") {
		$erroresA[] = "<p>La hora de llegada o la hora de salida no pueden estar vacías</p>";
	}else if($horallegada<$horasalida){
		$erroresA[] = "<p>La hora de llegada es menor que la hora de salida</p>";
	}
		
	// Validación de matricula del autobús
	if(!isset($nuevoViaje["autobus"])){
		$erroresA[] = "<p>La matrícula del autobus no puede estar vacía</p>";
	}else if(!preg_match("/^[0-9]{4}[A-Z]{3}$/",$nuevoViaje["autobus"])){
		$erroresA[] = "<p>Matrícula no válida: debe empezar con 4 digitos y seguir con 3 letras mayúsculas para terminar.</p>";
	}
	return $erroresA;
	}
	
	?>