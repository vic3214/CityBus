function ValidacionesRuta(){
	var noValidar = document.getElementById("#altaRuta").novalidate;
	
	if(!noValidar){
		var inter1 = validaCongruenciaHoras();
		var error1= validaMatricula();
		var error2 = validaHoraSalida();
		var error3 = validaPrecio();
		var error4 = validaRuta();
		var error5 = validaHoraLlegada();
		
		return (error1.length==0 && error4.length==0 && error3.length==0 && error2.length==0 && error5.length==0);
	}else{
		return true;
	}

}
function validaRuta(){
	var rutaV = document.getElementById("ruta");
	var ruta = rutaV.value;
	var valido = true;
	
	var expreg =/[0-9]{1,}/ ;
	valido = expreg.test(ruta);
	if(!valido){
		var error = "La ruta debe ser un número entero.";

	}else{
			var error = "";
	}
    rutaV.setCustomValidity(error);
	return error;
}
function validaMatricula(){
	var matriculaV = document.getElementById("autobus");
	var matricula = matriculaV.value;
	var valido = true;
	
	var expreg =/^[0-9]{4}[A-Z]{3}$/;
	
	valido = expreg.test(matricula);
	if(!valido){
		var error = "La matrícula introducida no es correcta";

	}else{
			var error = "";
	}
    matriculaV.setCustomValidity(error);
	return error;
}
function validaPrecio(){
	var precioV = document.getElementById("precio");
	var precio = precioV.value;
	var valido = true;
	
	var expreg =/[0-9]{1,}[,][0-9]{2}/;
	
	valido = expreg.test(precio);
	if(!valido){
		var error = "El precio debe tener dos cifras decimales, usando la coma para separar parte entera y decimal.";

	}else{
			var error = "";
	}
    precioV.setCustomValidity(error);
	return error;
}
function validaCongruenciaHoras(){
	
	var horallegadaV = document.getElementById("horallegada");
	var horallegada = horallegadaV.value;
	
	var horasalidaV = document.getElementById("horasalida");
	var horasalida = horasalidaV.value;
	var valido =false;
	
	// Digitos hora de salida
    var horaS=horasalida.charAt(0) + horasalida.charAt(1); //<= digitos hora
	var minS=horasalida.charAt(3) +horasalida.charAt(4) ; //<=  digitos minutos 
	var hS = parseInt(horaS,10);
	var mS = parseInt(minS,10);
	// Digitos hora llegada
	var horaL=horallegada.charAt(0) + horallegada.charAt(1); //<=  digitos hora 
	var minL=horallegada.charAt(3) + horallegada.charAt(4);//<=  digitos minutos
	var hL = parseInt(horaL,10);
	var mL = parseInt(minL,10);
	
	if(hS>hL){
		valido = true;
		identificador = 7;
	}else if((hS==hL) && (mS>mL)){
		valido = true;	
		identificador = 8;
	}else if((hS==hL) && (mS==mL)){
		valido = true;
		identificador = 9;
	}
	
	if(valido){
		var error = "La hora de salida es mayor o igual que la hora de llegada";

	}else{
			var error = "";
	}
    horallegadaV.setCustomValidity(error);
    horasalidaV.setCustomValidity(error);
	return error;
	
}

function validaHoraSalida(){
	var horasalidaV = document.getElementById("horasalida");
	var horasalida = horasalidaV.value;
	
	var horallegadaV = document.getElementById("horallegada");
	var horallegada = horallegadaV.value;
	
		// Digitos hora de salida
    var horaS=horasalida.charAt(0) + horasalida.charAt(1); //<= digitos hora
	var minS=horasalida.charAt(3) +horasalida.charAt(4) ; //<=  digitos minutos 
	var hS = parseInt(horaS,10);
	var mS = parseInt(minS,10);
	// Digitos hora llegada
	var horaL=horallegada.charAt(0) + horallegada.charAt(1); //<=  digitos hora 
	var minL=horallegada.charAt(3) + horallegada.charAt(4);//<=  digitos minutos
	var hL = parseInt(horaL,10);
	var mL = parseInt(minL,10);
	
	var a=horasalida.charAt(0); //<=2 digito hora 1
	var b=horasalida.charAt(1); //<4  digito hora 2
	var c=horasalida.charAt(2); //:   dos puntos
	var d=horasalida.charAt(3); //<=  digito minuto 2
	var e=horasalida.charAt(4); //<=     digito minuto 2
	var identificador=0;
	if(horallegada ==""){
		identidicador=0;
	}
	
	if(hS>hL){
		identificador = 7;
	}else if((hS==hL) && (mS>mL)){	
		identificador = 8;
	}else if((hS==hL) && (mS==mL)){
		identificador = 9;
	}
	if(horallegada ==""){
		identidicador=0;
	}
	if (c!=':') {
		identificador=6;
	}
		if (d>5) {
		identificador=5;
	}
		if ((a==2 && b>3) || (a>2)) {
		identificador=4;
	}
	if (horasalida=='') {
		identificador=1;
	}
	if (horasalida.length<5) {
		identificador=3;
	}
	if (horasalida.length>5) {
		identificador=2;
	}
	
  switch (identificador) {
  case 0:
  	var error = "";
    break;
  case 1:
    var error = "La fecha no puede estar vacía";
    break;
  case 2:
    var error = "Introdujo una cadena mayor a 5 caracteres";
    break;
  case 3:
    var error = "Introdujo una hora menor a 5 caracteres";
    break;
  case 4:
    var error = "El valor que introdujo en la Hora no corresponde, introduzca un digito entre 00 y 23";
    break;
  case 5:
    var error = "El valor que introdujo en los minutos no corresponde, introduzca un digito entre 00 y 59";
    break;
  case 6:
    var error = "Introduzca el caracter ':' para separar la hora y los minutos";
    break;
  case 7:
    var error = "La hora se llegada es menor que la hora de salida";
    break;
  case 8:
    var error = "Los minutos de la hora de llegada son menores que los d ela hora de salida ";
    break;
  case 9:
    var error = "Las horas de llegada y salida no pueden ser iguales";
    break;
  default:
    var error="El algoritmo no funciona";
    break;
}
    horasalidaV.setCustomValidity(error);
	return error;
}
function validaHoraLlegada(){
	var horasalidaV = document.getElementById("horasalida");
	var horasalida = horasalidaV.value;
	
	var horallegadaV = document.getElementById("horallegada");
	var horallegada = horallegadaV.value;
	
			// Digitos hora de salida
    var horaS=horasalida.charAt(0) + horasalida.charAt(1); //<= digitos hora
	var minS=horasalida.charAt(3) +horasalida.charAt(4) ; //<=  digitos minutos 
	var hS = parseInt(horaS,10);
	var mS = parseInt(minS,10);
	// Digitos hora llegada
	var horaL=horallegada.charAt(0) + horallegada.charAt(1); //<=  digitos hora 
	var minL=horallegada.charAt(3) + horallegada.charAt(4);//<=  digitos minutos
	var hL = parseInt(horaL,10);
	var mL = parseInt(minL,10);
	
	var a=horallegada.charAt(0); //<=2 digito hora 1
	var b=horallegada.charAt(1); //<4  digito hora 2
	var c=horallegada.charAt(2); //:   dos puntos
	var d=horallegada.charAt(3); //<=  digito minuto 2
	var e=horallegada.charAt(4); //<=     digito minuto 2
	var identificador=0;
	
	if(hS>hL){
		identificador = 7;
	}else if((hS==hL) && (mS>mL)){	
		identificador = 8;
	}else if((hS==hL) && (mS==mL)){
		identificador = 9;
	}

	if (c!=':') {
		identificador=6;
	}
		if (d>5) {
		identificador=5;
	}
		if ((a==2 && b>3) || (a>2)) {
		identificador=4;
	}
	if (horallegada=='') {
		identificador=1;
	}
	if (horallegada.length<5) {
		identificador=3;
	}
	if (horallegada.length>5) {
		identificador=2;
	}
	
  switch (identificador) {
  case 0:
  	var error = "";
    break;
  case 1:
    var error = "La fecha no puede estar vacía";
    break;
  case 2:
    var error = "Introdujo una cadena mayor a 5 caracteres";
    break;
  case 3:
    var error = "Introdujo una hora menor a 5 caracteres";
    break;
  case 4:
    var error = "El valor que introdujo en la Hora no corresponde, introduzca un digito entre 00 y 23";
    break;
  case 5:
    var error = "El valor que introdujo en los minutos no corresponde, introduzca un digito entre 00 y 59";
    break;
  case 6:
    var error = "Introduzca el caracter ':' para separar la hora y los minutos";
    break;
   case 7:
    var error = "La hora se llegada es menor que la hora de salida";
    break;
  case 8:
    var error = "Los minutos de la hora de llegada son menores que los dela hora de salida ";
    break;
  case 9:
    var error = "Las horas de llegada y salida no pueden ser iguales";
    break;
  default:
    var error="El algoritmo no funciona";
    break;
}
    horallegadaV.setCustomValidity(error);
	return error;
}

