//Validaciones de accion_alta_usuario

function ValidacionesUsuario(){
	var noValidar = document.getElementById("#altaUsuario").novalidate;
	
	if(!noValidar){
		var error1= validaPass();
		var error2= confirmaPass();
		var error3 = validaNif();
		var error4 = validaCorreo();
		
		return (error1.length==0 && error2.length==0 && error3.length==0 && error4.length==0 );
	}else{
		return true;
	}
}
function validaPass(){
	var passV = document.getElementById("pass");
	var pass= passV.value;
	var valido = true;
	
    var contieneDigito = /\d/;
		var contieneMayus = /[A-Z]/;
		var contieneMinus = /[a-z]/;
		
		valido =(contieneDigito.test(pass)) && (contieneMayus.test(pass)) && (contieneMinus.test(pass) && (pass.length>=8));
		
		// Si no cumple las restricciones, devolvemos un error
		if(!valido){
			var error = "La contraseña debe tener al menos ocho carácteres, un dígito, una mayúscula y una minúscula";
		}else{
			var error = "";
		}
	    passV.setCustomValidity(error);
		return error;	
}
	function confirmaPass(){
		
        var passV = document.getElementById("pass");
		var pass = password.value;
	
		var passconfirm = document.getElementById("confirmpass");
		var confirmacion = passconfirm.value;

		// Los comparamos
		if (pass != confirmacion) {
			var error = "Las contraseñas no coinciden";
		}else{
			var error = "";
		}

		passconfirm.setCustomValidity(error);

		return error;
	}
function validaNif(){
	var nifV =document.getElementById("nif");
	var nif= nifV.value;
	var valido = true;
	
	var contieneLetra = /[A-Z]/;
	var contieneNums = /[0-9]{8}/;
	
	valido = (contieneLetra.test(nif) && contieneNums.test(nif));
	
	if(!valido){
		var error = "El NIF debe contener ocho digitos seguidos de una letra en mayúscula";
	}else{
		var error = "";
	}
	nifV.setCustomValidity(error);
	return error;
}
function validaCorreo(){
	var correoV= document.getElementById("email");
	var correo = correoV.value;
	var valido = true;
	var exprereg = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;
	valido = exprereg.test(correo);
	if(!valido){
		var error = "El correo que has instroducido no es válido";
	}else{
		var error = "";
	}
	correoV.setCustomValidity(error);
	return error;
}

