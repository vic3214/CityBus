<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Contacta con CityBus</title>
<link rel="stylesheet" href="css/CSS.css" />
</head>

<body>
	<?php
	include_once("cabecera.php");
	?>
	<h1 align="center">Contactos:</h1>
	
	<div align="center">
		<br />
		<p>
			<h3>Álvaro Cobo Calero -> alvcobcal@alum.us.es</h3>
			
		</p>
		<br />
		<p>
			<h3>Víctor Caballero Sánchez -> viccabsan@alum.us.es</h3>
		</p>
		<br />
		
	</div>
	<hr />
	<?php
     include_once("pie.php");
?>
	
</body>
	
	
	
	
</html>