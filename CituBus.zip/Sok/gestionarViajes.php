<?php
	function listaViajes($conexion){
		$consulta = "SELECT nombreruta, fechaviaje, autobus,precio,horallegada,horasalida,idviaje from viajes NATURAL JOIN rutas where (viajes.ruta = rutas.idruta) order by viajes.fechaviaje";
		return $conexion->query($consulta);
	}
	function alta_Viaje($conexion,$nuevoViaje){
	$fechaviaje = date('d/m/Y', strtotime($nuevoViaje["fechaviaje"]));
	try {
		$consulta = "CALL insertaviaje(:fechaviaje, :autobus, :ruta, :precio, :horasalida, :horallegada)";
		
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':fechaviaje',$fechaviaje);
		$stmt->bindParam(':autobus',$nuevoViaje["autobus"]);
		$stmt->bindParam(':ruta',$nuevoViaje["ruta"]);
		$stmt->bindParam(':precio',$nuevoViaje["precio"]);
		$stmt->bindParam(':horasalida',$nuevoViaje["horasalida"]);
		$stmt->bindParam(':horallegada',$nuevoViaje["horallegada"]);
		$stmt->execute();
		
		return true;
	} catch(PDOException $e) {
		return false;
    }
		
}
 
?>
