<footer>
	<p align="center">&copy; CityBus</p>
</footer>
