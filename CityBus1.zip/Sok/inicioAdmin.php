<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Bienvenido a CityBus</title>
<link rel="stylesheet" href="css/CSS.css" />
</head>

<body class="cuerpo">
		<div>
			
			
			<nav> 
				<ul class="nav">
					<li><a href="logout.php">Desconéctate</a></li>
					<li><a href="#">Servicios</a>
						<ul>
							<li class="borde3"><a href="form_admin.php">Registro Ruta</a></li>
								<ul>
									<li class="borde2"><a href="compra_billete.php">Billetes disponibles</a></li>
								</ul>
							</li>
						</ul>
					<li><a href="contacto.php">Contacto</a></li>
				</ul>
			</nav>
		</div>
		<div>
				<img class="pos" src="imagenes/logodef.jpg" alt="Logo CityBus" title="CityBus"/>
		</div>
		<?php include_once("pie.php")?>
</body>
</html>