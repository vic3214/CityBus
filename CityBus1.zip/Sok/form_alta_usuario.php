<?php
	session_start();
	
	require_once("gestionBD.php");
	
	
	// Si no existen datos del formulario en la sesión, se crea una entrada con valores por defecto
	if (!isset($_SESSION["formulario"])) {
		$formulario['nif'] = "";
		$formulario['nombre'] = "";
		$formulario['apellidos'] = "";
	    $formulario['tipoviaje'] = "";
		$formulario['email'] = "";
		$formulario['pass'] = "";
		$_SESSION["formulario"] = $formulario;
	}
	
	// Si ya existían valores, los cogemos para inicializar el formulario
	else{
		$formulario = $_SESSION["formulario"];
	}
			
	// Si hay errores de validación, hay que mostrarlos y marcar los campos (El estilo viene dado y ya se explicará)
	if (isset($_SESSION["errores"])){
		$errores = $_SESSION["errores"];
		unset($_SESSION["errores"]);
	}
		
	// Creamos una conexión con la BD
	$conexion = crearConexionBD();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">  
  <link rel="stylesheet" type="text/css" href="css/CSS.css" />
  <link rel="stylesheet" type="text/css" href="css/efecto_form.css" />
  <title>CityBus | Registro</title>
</head>

<body>
	
	<?php
		include_once("cabecera.php");
	?>
	
	<?php 
		// Mostrar los erroes de validación (Si los hay)
		if (isset($errores) && count($errores)>0) { 
	    	echo "<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
    		foreach($errores as $error){
    			echo $error;
			} 
    		echo "</div>";
  		}
	?>
	
	<form class="formulario" id="altaUsuario" method="get" action="validacion_alta_usuario.php" onsubmit="return ValidacionesUsuario()">  
			<h1 class="titulo">¡Rellena el formulario y registrate!</h1>
			
			<input class="inputss" id="nif" name="nif" type="text"  pattern="^[0-9]{8}[A-Z]" title="Ocho dígitos seguidos de una letra mayúscula" oninput="validaNif();" value="<?php echo $formulario['nif'];?>" required />
			<label class="label" for="nif">NIF<em>*</em></label>
			
			<input class="inputss" id="nombre" name="nombre" type="text"  value="<?php echo $formulario['nombre'];?>" required/>
			<label class="label" for="nombre">Nombre:<em>*</em></label>

			<input class="inputss" id="apellidos" name="apellidos" type="text" value="<?php echo $formulario['apellidos'];?>"/>
			<label class="label" for="apellidos">Apellidos:</label>
			
			<input class="inputss" id="email" name="email"  type="email" oninput="validaCorreo();" value="<?php echo $formulario['email'];?>" required/>
			<label class="label" for="email">Email:<em>*</em></label>
		
			<input class="inputss" type="password" name="pass" id="pass"  oninput="validaPass();" required/>
			<label class="label" for="pass">Password:<em>*</em></label>
			
			<input class="inputss" type="password" name="confirmpass" id="confirmpass"  oninput="confirmaPass();" required/>
			<label class="label" for="confirmpass">Confirmar Password:<em>*</em> </label>

			<input class="boton" type="submit" value="Registrate" />
	</form>
	  

	<?php
		include_once("pie.php");
		cerrarConexionBD($conexion);
	?>
	 <script src="JavaScript/validacion_alta_usuario.js" type="text/javascript"></script>
	</body>
</html>