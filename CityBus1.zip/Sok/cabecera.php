<header>
    <p id="fondo"><img id="logo" src="imagenes/logodef.jpg" alt="CityBus" title="CityBus"></p>
</header>