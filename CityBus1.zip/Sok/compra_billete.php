<?php
	session_start();
	
	require_once("gestionBD.php");
	require_once("gestionarViajes.php");
	
	if (isset($_SESSION["viaje"])){
		$viaje = $_SESSION["viaje"];
		unset($_SESSION["viaje"]);
	}	
	$conexion = crearConexionBD();
	$filas = listaViajes($conexion);
	cerrarConexionBD($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Viajes disponibles para comprar</title>
  <link rel="stylesheet" type="text/css" href="css/CSS.css" />
</head>

<body>
<main>
<?php
	include_once("cabecera.php");
?>
<br />
<fieldset><legend>Viajes Disponibles</legend>
	<?php
		foreach($filas as $fila) {
			//Cambiado el div class=viaje
	?>
	<article>
		<form method="get" action="controlador_viajes.php">
			<div>
					<div>
					<input type="hidden" id="IDVIAJE" name="IDVIAJE" value="<?php echo $fila['IDVIAJE'] ?>" />
					<div class="ruta"><h3> <?php echo $fila['NOMBRERUTA'] ?> </h3></div>
					<div  class="viaje"><h4><em><?php echo "Fecha del viaje: ".$fila['FECHAVIAJE']. "<br>"."Mátricula del Autobús: ".$fila['AUTOBUS']."<br>"."Hora  de Salida: ".$fila['HORASALIDA']." - "."Hora de llegada: "
					.$fila['HORALLEGADA']."<br>"."Precio del billete: ".$fila['PRECIO']."€";?></h4></div>
					<hr />
						
					</div>
					</div>
					</form>
					</article>

					
<?php } ?>
</main>
</fieldset>
<br />

<?php
	include_once("pie.php");
?>

</body>
</html>