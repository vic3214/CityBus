<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Sobre CityBus</title>
<link rel="stylesheet" href="css/CSS.css" />
</head>

<body>
	<?php 
	include_once("cabecera.php");
	?>
	<h1 align="center">Somos dos estudiantes de IISSI2</h1>
	
</body>
	
	
	
	
</html>